from django.apps import AppConfig


class ReqChallConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'req_chall'
